<?php

	$Config = array(
			  "PRODUCT_NAME"		=> "TNA 101"
			, "PRODUCT_URL"			=> "http://www.tna101.co.za"
			, "EMAIL_SIGNATURE"		=> "Regards<br/>"
			, "SUPPORT_EMAIL"		=> "support@tna101.co.za"
			, "SMTP_SERVER"			=> "mail.tna101.co.za"
			, "SMTP_USERNAME"		=> "support@tna101.co.za"
			, "SMTP_PASSWORD"		=> "support"
		);
	
	if (file_exists("../PHPMailer_v5.1/class.phpmailer.php"))
		require_once("../PHPMailer_v5.1/class.phpmailer.php");
	else if (file_exists("PHPMailer_v5.1/class.phpmailer.php"))
		require_once("PHPMailer_v5.1/class.phpmailer.php");
	
	function notify_password_reset($obj, $new_pwd){
		global $Config;
		__notify_send_mail($obj->username
				, $Config["PRODUCT_NAME"]."Your password has been reset"
				, "Here is your new password <b>".$new_pwd."</b>");
	}

	function notify_new_user($obj){
		global $Config;
		
		$body = <<<EOT
		<p>Hi {$obj->data->firstname},</p><br />
		<p>
		Thank you for joining {$Config["PRODUCT_NAME"]}. We hope that you enjoy using our product.
		</p>
		<p>
		To log onto your profile, you can point your browser to <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a>
		</p>
		<p>
		Your logon details are:<br />
		&nbsp; &nbsp; &nbsp; &nbsp; username: {$obj->data->username} <br />
		&nbsp; &nbsp; &nbsp; &nbsp; password: {$obj->data->password} <br />
		</p>
		<p>
		Once you have logged on you can subscribe to different subscriptions and start working on them or managing them.
		</p>
		<p>
		You can also create your own subscription and let other people join it.
		</p>
		<p>
		Enjoy :-)
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;
		
		__notify_send_mail($obj->data->username
				, $Config["PRODUCT_NAME"]." - New Registration"
				, $body);
	}
	
	function notify_subscription_request($user, $subscription){
		$db = new CDatabase();
		global $Config;
		
		//GET THE SUBSCRIBER DETAILS
		$sql = "SELECT firstname, username
				FROM administrators
				WHERE id = '".$_SESSION["admin_id"]."'";
		$user_rst = $db->run_query($sql);

		$to = array();
		//GET THE OWNER DETAILS
		$sql = "SELECT 
					  D.name AS subscription
					, A.username AS auth_email
					, A.firstname AS auth_firstname
					, A.surname  AS auth_surname
				FROM administrators A
				INNER JOIN administrator_clients B ON B.administrator = A.id
				INNER JOIN security_details C ON C.security_role = B.security_role_given
				INNER JOIN clients D ON B.client = D.id
				WHERE C.security_type = 158
				AND B.client = '".$subscription->client."'";
		logging($sql);
		$rst_group = $db->run_query($sql);
		if (count($rst_group) == 0)
			exit_with_response(-1, "There is no authorisers listed for the client you requested access to.");
			
		//GET THE SUBSCRIBER DETAILS
		$sql = "SELECT name AS security_role
				FROM security_roles 
				WHERE id = '".$subscription->security_role."'";
		$sub_rst = $db->run_query($sql);
		
		//EMAIL BODY FOR AUTHORISERS
		$body = <<<EOT
		<p>Hi,</p><br />
		<p>
		{$user_rst[0]["username"]} has requested access of role-type {$sub_rst[0]["security_role"]} to subscription {$rst_group[0]["subscription"]}, and you have been identified as one of the authorisers.
		</p>
		<p>
		Please log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to  authorise the user with the appropriate permissions.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;
		foreach($rst_group as $rst){
			$to[] = $rst["auth_email"];
		}
		__notify_send_mail($to
				, $Config["PRODUCT_NAME"]." - Access Requested"
				, $body);
		
		//EMAIL BODY FOR REQUEST
		$body = <<<EOT
		<p>Hi {$user_rst[0]["firstname"]},</p><br />
		<p>
		Your request for access to subscription {$rst_group[0]["subscription"]} with a role-type of {$sub_rst[0]["security_role"]} has been sent to the authoriser(s).
		</p>
		<p>
		An email will be sent to you as soon as one of the authorisers has given you access.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;
		
		__notify_send_mail($user_rst[0]["username"]
				, $Config["PRODUCT_NAME"]." - Access Requested"
				, $body);
		
	}

	function notify_subscription_authorised($user, $subscription){
		global $Config;
		$db = new CDatabase();
		
		$to = array();
		//GET THE OWNER DETAILS
		$sql = "SELECT 
					  B.name AS group_name
					, CONCAT(C.firstname, ' ', C.surname) AS auth_fullname
					, C.username AS auth_uid
					, CONCAT(D.firstname, ' ', D.surname) AS fullname
					, D.username
					, E.name AS security_role
				FROM administrator_clients A
				INNER JOIN clients B ON B.id = A.client
				INNER JOIN administrators C ON C.id = A.authorised_by
				INNER JOIN administrators D ON D.id = A.administrator
				INNER JOIN security_roles E ON E.id = A.security_role_given
				WHERE A.authorised_by IS NOT NULL
				AND A.authorised_on IS NOT NULL
				AND A.security_role_given IS NOT NULL
				AND A.client = ".db_format($subscription->client)."
				AND A.administrator = ".db_format($subscription->administrator)."
				AND A.authorised_by = ".db_format($user->created_by);
				
		$rst = $db->run_query($sql);
		$rst = $rst[0];
		
		//EMAIL BODY FOR AUTHORISERS
		$body = <<<EOT
		<p>Hi {$rst["fullname"]},</p><br />
		<p>
		{$rst["auth_fullname"]} has given you access to subscription {$rst["group_name"]} with a role-type of {$rst["security_role"]}.
		</p>
		<p>
		Please log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to view the activity of the subscription.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;
		__notify_send_mail($rst["username"]
				, $Config["PRODUCT_NAME"]." - Access Granted"
				, $body);

	}

	function notify_story_status_change($obj){
		global $Config;
		
		$to = array();
		//FIRST GET THE LIST OF PEOPLE THAT WANTS TO BE NOTIFIED
		$sql = "SELECT A.username FROM team_members A
				INNER JOIN notifications B ON A.id = B.team_member
				WHERE B.notification_level = 3
				AND status_change = 1
				AND B.lookup_key = '".format_db_field($obj->id)."'";
				
		$dist_rst = run_query($sql);
		foreach($dist_rst as $rst){
			if (!in_array($rst["username"], $to))
				$to[] = $rst["username"];
		}
		if (count($to) == 0) return;
		//IF WE GET HERE THERE IS PEOPLE THAT IS INTERESTED
		
		//GET THE STATUS NAME
		$sql = "SELECT A.tracking_number
					, B.name AS scrum_state
					, C.name AS status
				FROM stories A
				INNER JOIN scrum_states B ON A.scrum_state = B.id
				INNER JOIN status_codes C ON A.status_code = C.id
				WHERE A.id = '".format_db_field($obj->id)."'
				AND A.group_id = '".format_db_field($obj->group_id)."'";
		$rst = run_query($sql);
		if (count($rst) == 0) return;
		
		$rst = $rst[0];

		$body = <<<EOT
		<p>
		<table border=0>
			<tbody>
				<tr>
					<td>Tracking Number</td>
					<td>{$rst["tracking_number"]}</td>
				</tr>
				<tr>
					<td>Scrum State</td>
					<td>{$rst["scrum_state"]}</td>
				</tr>
				<tr>
					<td>Status</td>
					<td>{$rst["status"]}</td>
				</tr>
			</tbody>
		</table>
		</p>
		<p>
		You can log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to get further details.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;

		__notify_send_mail($to
				, $rst["tracking_number"]." - Status Changed"
				, $body);
	}

	function notify_story_add_note($obj){
		global $Config;
		
		$to = array();
		//FIRST GET THE LIST OF PEOPLE THAT WANTS TO BE NOTIFIED
		$sql = "SELECT A.username FROM team_members A
				INNER JOIN notifications B ON A.id = B.team_member
				WHERE B.notification_level = 3
				AND notes_added = 1
				AND B.lookup_key = '".format_db_field($obj->id)."'";
				
		$dist_rst = run_query($sql);
		foreach($dist_rst as $rst){
			if (!in_array($rst["username"], $to))
				$to[] = $rst["username"];
		}
		if (count($to) == 0) return;
		
		//IF WE GET HERE THERE IS PEOPLE THAT IS INTERESTED
		
		//GET THE STATUS NAME
		$sql = "SELECT A.tracking_number
					, B.name AS scrum_state
					, C.name AS status
				FROM stories A
				INNER JOIN scrum_states B ON A.scrum_state = B.id
				INNER JOIN status_codes C ON A.status_code = C.id
				WHERE A.id = '".format_db_field($obj->id)."'
				AND A.group_id = '".format_db_field($obj->group_id)."'";
		$rst = run_query($sql);
		if (count($rst) == 0) return;
		
		$rst = $rst[0];
		
		$body = <<<EOT
		<p>
		<table border=0>
			<tbody>
				<tr>
					<td>Tracking Number</td>
					<td>{$rst["tracking_number"]}</td>
				</tr>
				<tr>
					<td>Note Added</td>
					<td>{$obj->notes}</td>
				</tr>
			</tbody>
		</table>
		</p>
		<p>
		You can log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to get further details.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;

		__notify_send_mail($to
				, $rst["tracking_number"]." - New Notes Added"
				, $body);
	}

	function notify_story_impediment_create($obj){
		global $Config;
		
		$to = array();
		//FIRST GET THE LIST OF PEOPLE THAT WANTS TO BE NOTIFIED
		$sql = "SELECT A.username FROM team_members A
				INNER JOIN notifications B ON A.id = B.team_member
				WHERE B.notification_level = 3
				AND impediment_created = 1
				AND B.lookup_key = '".format_db_field($obj->story)."'";
				
		$dist_rst = run_query($sql);
		foreach($dist_rst as $rst){
			if (!in_array($rst["username"], $to))
				$to[] = $rst["username"];
		}
		if (count($to) == 0) return;
		
		//IF WE GET HERE THERE IS PEOPLE THAT IS INTERESTED
		
		//GET THE STATUS NAME
		$sql = "SELECT A.tracking_number
					, B.name AS scrum_state
					, C.name AS status
				FROM stories A
				INNER JOIN scrum_states B ON A.scrum_state = B.id
				INNER JOIN status_codes C ON A.status_code = C.id
				WHERE A.id = '".format_db_field($obj->story)."'
				AND A.group_id = '".format_db_field($obj->group_id)."'";
		$rst = run_query($sql);
		if (count($rst) == 0) return;
		
		$rst = $rst[0];
		
		$sql = "SELECT username FROM team_members WHERE id = '".format_db_field($obj->created_by)."'";
		$user = run_query($sql);
		if (count($user) == 0)
			exit_with_response(-1, "Failed to load username of the person who raised the impediment");
		$user = $user[0];
		
		$body = <<<EOT
		<p>
		<table border=0>
			<tbody>
				<tr>
					<td>Tracking Number</td>
					<td>{$rst["tracking_number"]}</td>
				</tr>
				<tr>
					<td>Raised by</td>
					<td>{$user["username"]}</td>
				</tr>
				<tr>
					<td>Impediment</td>
					<td>{$obj->notes}</td>
				</tr>
			</tbody>
		</table>
		</p>
		<p>
		You can log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to get further details.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;

		__notify_send_mail($to
				, $rst["tracking_number"]." - Impediment Created"
				, $body);
	}

	function notify_story_impediment_closed($obj){
		global $Config;
		
		$to = array();
		//FIRST GET THE LIST OF PEOPLE THAT WANTS TO BE NOTIFIED
		$sql = "SELECT A.username FROM team_members A
				INNER JOIN notifications B ON A.id = B.team_member
				WHERE B.notification_level = 3
				AND impediment_closed = 1
				AND B.lookup_key = '".format_db_field($obj->story)."'";
				
		$dist_rst = run_query($sql);
		foreach($dist_rst as $rst){
			if (!in_array($rst["username"], $to))
				$to[] = $rst["username"];
		}
		if (count($to) == 0) return;
		
		//IF WE GET HERE THERE IS PEOPLE THAT IS INTERESTED
		
		//GET THE STATUS NAME
		$sql = "SELECT A.tracking_number
					, B.name AS scrum_state
					, C.name AS status
				FROM stories A
				INNER JOIN scrum_states B ON A.scrum_state = B.id
				INNER JOIN status_codes C ON A.status_code = C.id
				WHERE A.id = '".format_db_field($obj->story)."'
				AND A.group_id = '".format_db_field($obj->group_id)."'";
		$rst = run_query($sql);
		if (count($rst) == 0) return;
		
		$rst = $rst[0];
		
		$sql = "SELECT username FROM team_members WHERE id = '".format_db_field($obj->created_by)."'";
		$user = run_query($sql);
		if (count($user) == 0)
			exit_with_response(-1, "Failed to load username of the person who raised the impediment");
		$user = $user[0];
		
		$body = <<<EOT
		<p>
		<table border=0>
			<tbody>
				<tr>
					<td>Tracking Number</td>
					<td>{$rst["tracking_number"]}</td>
				</tr>
				<tr>
					<td>Closed by</td>
					<td>{$user["username"]}</td>
				</tr>
				<tr>
					<td>Impediment</td>
					<td>{$obj->notes}</td>
				</tr>
			</tbody>
		</table>
		</p>
		<p>
		You can log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to get further details.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;

		__notify_send_mail($to
				, $rst["tracking_number"]." - Impediment Closed"
				, $body);
	}

	function notify_story_sprint_change($obj){
		global $Config;
		$is_removed = false;
		
		$to = array();
		//FIRST GET THE LIST OF PEOPLE THAT WANTS TO BE NOTIFIED
		$sql = "SELECT A.username FROM team_members A
				INNER JOIN notifications B ON A.id = B.team_member
				WHERE B.notification_level = 3
				AND sprint_change = 1
				AND B.lookup_key = '".format_db_field($obj->story)."'";
				
		$dist_rst = run_query($sql);
		foreach($dist_rst as $rst){
			if (!in_array($rst["username"], $to))
				$to[] = $rst["username"];
		}
		if (count($to) == 0) return;
		
		//IF WE GET HERE THERE IS PEOPLE THAT IS INTERESTED
		
		//CHECK IF THERE IS A RECORD FOR THIS SPRINT
		//WHERE THE REMOVED-BY IS NULL
		//IF NOT IT MEANS WE JUST REMOVED IT FROM THE SPRINT
		$sql = "SELECT * FROM story_sprints
				WHERE removed_on IS NULL 
				AND removed_by IS NULL 
				AND story = '".format_db_field($obj->story)."'
				AND group_id = '".format_db_field($obj->group_id)."'
				AND sprint = '".format_db_field($obj->sprint)."'";
		$rst = run_query($sql);
		if (count($rst) == 0) $is_removed = true;
		
		//GET SPRINT DETAILS
		$sql = "SELECT name FROM sprints 
				WHERE id = '".format_db_field($obj->sprint)."'
				AND group_id = '".format_db_field($obj->group_id)."'";
		$rst = run_query($sql);
		if (count($rst) == 0)
			exit_with_response(-1, "Failed to load sprint details for notification");
		
		$rst = $rst[0];
		
		//STORY DETAILS
		$sql = "SELECT tracking_number FROM stories 
				WHERE id = '".format_db_field($obj->story)."'
				AND group_id = '".format_db_field($obj->group_id)."'";
		$story = run_query($sql);
		if (count($story) == 0)
			exit_with_response(-1,"Failed to load the story for the sprint notification");
		
		$story = $story[0];
		
		$sql = "SELECT username FROM team_members WHERE id = '".format_db_field($obj->created_by)."'";
		$user = run_query($sql);
		if (count($user) == 0)
			exit_with_response(-1, "Failed to load username of the person who raised the impediment");
		$user = $user[0];
		$label_user = $is_removed == true ? "Removed by" : "Added by";
		$label_subject = $is_removed == true ? "Removed from sprint" : "Added to sprint";
		$body = <<<EOT
		<p>
		<table border=0>
			<tbody>
				<tr>
					<td>Tracking Number</td>
					<td>{$story["tracking_number"]}</td>
				</tr>
				<tr>
					<td>{$label_user}</td>
					<td>{$user["username"]}</td>
				</tr>
				<tr>
					<td>Sprint</td>
					<td>{$rst["name"]}</td>
				</tr>
			</tbody>
		</table>
		</p>
		<p>
		You can log onto <a href="{$Config["PRODUCT_URL"]}">{$Config["PRODUCT_URL"]}</a> to get further details.
		</p>
		<p>
		Thank you.
		</p>
		<p>
		{$Config["EMAIL_SIGNATURE"]}
		</p>
EOT;

		__notify_send_mail($to
				, $story["tracking_number"]." - ".$label_subject
				, $body);
	}

	function __notify_send_mail($to, $subject, $body){
		global $Config;
		
		if (is_array($to))
			$email_to = implode(";", $to);
		else
			$email_to = $to;
		
		$date = date("d F Y H:i:s");
		$file_body = <<<EOT
				<b>To: </b>{$email_to}<br/>
				<b>Subject: </b>{$subject}<br/>
				<b>Sent on: </b>{$date}<br/>
				<hr/>
				{$body}
EOT;
		$base = "./temp/";
		if (file_exists("./temp"))
			$base = "./temp/";
		else if (file_exists("../temp/"))
			$base = "../temp/";
		else{ 
			exit_with_response(-1, "No where to put the email file :-(");
		}
		file_put_contents($base.$subject.".html",$file_body);
		return;
		
		$mail = new PHPMailer();
		$mail->IsSMTP(); // set mailer to use SMTP
		$mail->SMTPDebug = 1;
		$mail->SMTPAuth = true; // turn on SMTP authentication
		//$mail->SMTPSecure = 'ssl';
		$mail->Host = $Config["SMTP_SERVER"]; //"mail.tna101.co.za"; // specify main and backup server

		$mail->Port = 25;
		$mail->Username = $Config["SMTP_USERNAME"]; //"support@tna101.co.za"; // SMTP username
		$mail->Password = $Config["SMTP_PASSWORD"]; //"support"; // SMTP password
		$mail->From = $Config["SUPPORT_EMAIL"]; //do NOT fake header.
		$mail->FromName = $Config["PRODUCT_NAME"];
		$mail->AddReplyTo($Config["SUPPORT_EMAIL"], "Support and Help"); //optional

		$mail->IsHTML(true);
		if (is_array($to)){
			foreach($to as $add){
				$mail->AddAddress($add); // Email on which you want to send mail
			}
		}
		else
			$mail->AddAddress($to); // Email on which you want to send mail

		$mail->Subject = $subject;

		$mail->Body = $body;

		if(!$mail->Send()){
			exit_with_response(-1, $mail->ErrorInfo);
		}
	}
?>
